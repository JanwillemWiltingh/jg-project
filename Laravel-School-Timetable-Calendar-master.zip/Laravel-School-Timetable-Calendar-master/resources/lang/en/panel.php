<?php

return [
    'site_title' => 'School Timetable',
];
